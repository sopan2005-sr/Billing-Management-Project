"use strict";

/* =========================
   SmartBill Prototype
   ========================= */

const pages = {
    welcome: document.getElementById("welcomePage"),
    login: document.getElementById("loginPage"),
    dashboard: document.getElementById("dashboardPage"),
    billing: document.getElementById("billingPage"),
    bills: document.getElementById("billsPage"),
    complete: document.getElementById("completePage")
};

let items = [];
let bills = [];
let invoiceCounter = 1001;
let lastGeneratedBill = null;

/* =========================
   Utility Functions
   ========================= */

function showPage(pageName) {
    Object.values(pages).forEach(function(page) {
        page.classList.remove("active");
    });

    if (pages[pageName]) {
        pages[pageName].classList.add("active");
    }

    window.scrollTo(0, 0);

    if (pageName === "dashboard") {
        updateDashboard();
    }

    if (pageName === "bills") {
        renderBills();
    }

    if (pageName === "billing") {
        prepareNewBill();
    }
}

function formatCurrency(value) {
    return "₹" + Number(value || 0).toFixed(2);
}

function getToday() {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
}

function getElement(id) {
    return document.getElementById(id);
}

/* =========================
   Welcome
   ========================= */

getElement("getStartedBtn").addEventListener("click", function() {
    showPage("login");
});

/* =========================
   Login
   ========================= */

getElement("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const username = getElement("username").value.trim();
    const password = getElement("password").value;

    const error = getElement("loginError");

    if (username === "admin" && password === "1234") {
        error.textContent = "";

        getElement("username").value = "";
        getElement("password").value = "";

        showPage("dashboard");
    } else {
        error.textContent = "Invalid username or password.";
    }
});

getElement("togglePassword").addEventListener("click", function() {
    const passwordInput = getElement("password");

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        this.textContent = "Hide";
    } else {
        passwordInput.type = "password";
        this.textContent = "Show";
    }
});

/* =========================
   Navigation
   ========================= */

document.querySelectorAll(".nav-btn").forEach(function(button) {
    button.addEventListener("click", function() {

        const target = this.getAttribute("data-page");

        document.querySelectorAll(".nav-btn").forEach(function(btn) {
            btn.classList.remove("active");
        });

        document.querySelectorAll(
            `.nav-btn[data-page="${target}"]`
        ).forEach(function(btn) {
            btn.classList.add("active");
        });

        showPage(target);
    });
});

/* =========================
   Logout
   ========================= */

function logout() {
    showPage("welcome");

    items = [];
    lastGeneratedBill = null;
}

getElement("logoutBtn").addEventListener("click", logout);

document.querySelectorAll(".logout-common").forEach(function(button) {
    button.addEventListener("click", logout);
});

getElement("completeLogoutBtn").addEventListener("click", logout);

/* =========================
   Dashboard
   ========================= */

getElement("newBillBtn").addEventListener("click", function() {
    showPage("billing");
});

getElement("viewBillsBtn").addEventListener("click", function() {
    showPage("bills");
});

function updateDashboard() {

    let totalSales = 0;
    const customers = new Set();

    bills.forEach(function(bill) {
        totalSales += Number(bill.total);

        if (bill.customer) {
            customers.add(bill.customer.toLowerCase());
        }
    });

    getElement("totalSales").textContent = formatCurrency(totalSales);
    getElement("totalBills").textContent = bills.length;
    getElement("totalCustomers").textContent = customers.size;
}

/* =========================
   Billing
   ========================= */

function prepareNewBill() {

    getElement("invoiceNumber").value =
        "INV-" + invoiceCounter;

    getElement("invoiceDate").value = getToday();

    clearProductInputs();

    if (items.length === 0) {
        renderItems();
    }
}

function clearProductInputs() {
    getElement("productName").value = "";
    getElement("quantity").value = "1";
    getElement("rate").value = "";
    getElement("discount").value = "0";
    getElement("gst").value = "18";
}

getElement("addItemBtn").addEventListener("click", function() {

    const productName = getElement("productName").value.trim();
    const quantity = Number(getElement("quantity").value);
    const rate = Number(getElement("rate").value);
    const discount = Number(getElement("discount").value) || 0;
    const gst = Number(getElement("gst").value) || 0;

    if (!productName) {
        showBillingMessage("Please enter product name.");
        return;
    }

    if (!quantity || quantity <= 0) {
        showBillingMessage("Quantity must be greater than 0.");
        return;
    }

    if (rate < 0 || !getElement("rate").value) {
        showBillingMessage("Please enter a valid rate.");
        return;
    }

    if (discount < 0 || discount > 100) {
        showBillingMessage("Discount must be between 0 and 100.");
        return;
    }

    if (gst < 0 || gst > 100) {
        showBillingMessage("GST must be between 0 and 100.");
        return;
    }

    items.push({
        product: productName,
        quantity: quantity,
        rate: rate,
        discount: discount,
        gst: gst
    });

    clearProductInputs();
    hideBillingMessage();
    renderItems();
});

function calculateItem(item) {

    const baseAmount = item.quantity * item.rate;

    const discountAmount =
        baseAmount * (item.discount / 100);

    const taxableAmount =
        baseAmount - discountAmount;

    const gstAmount =
        taxableAmount * (item.gst / 100);

    const finalAmount =
        taxableAmount + gstAmount;

    return {
        base: baseAmount,
        discountAmount: discountAmount,
        taxable: taxableAmount,
        gstAmount: gstAmount,
        finalAmount: finalAmount
    };
}

function renderItems() {

    const tbody = getElement("itemsTableBody");

    tbody.innerHTML = "";

    let subtotal = 0;
    let totalDiscount = 0;
    let totalGST = 0;
    let grandTotal = 0;

    items.forEach(function(item, index) {

        const calculation = calculateItem(item);

        subtotal += calculation.base;
        totalDiscount += calculation.discountAmount;
        totalGST += calculation.gstAmount;
        grandTotal += calculation.finalAmount;

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${escapeHTML(item.product)}</td>
            <td>${item.quantity}</td>
            <td>${formatCurrency(item.rate)}</td>
            <td>${item.discount}%</td>
            <td>${item.gst}%</td>
            <td>${formatCurrency(calculation.finalAmount)}</td>
            <td>
                <button class="remove-btn" data-index="${index}">
                    Remove
                </button>
            </td>
        `;

        tbody.appendChild(row);
    });

    document.querySelectorAll(".remove-btn").forEach(function(button) {

        button.addEventListener("click", function() {

            const index = Number(this.getAttribute("data-index"));

            items.splice(index, 1);

            renderItems();
        });
    });

    getElement("subtotal").textContent =
        formatCurrency(subtotal);

    getElement("discountTotal").textContent =
        formatCurrency(totalDiscount);

    getElement("gstTotal").textContent =
        formatCurrency(totalGST);

    getElement("grandTotal").textContent =
        formatCurrency(grandTotal);
}

function getBillTotals() {

    let subtotal = 0;
    let discount = 0;
    let gst = 0;
    let total = 0;

    items.forEach(function(item) {

        const calculation = calculateItem(item);

        subtotal += calculation.base;
        discount += calculation.discountAmount;
        gst += calculation.gstAmount;
        total += calculation.finalAmount;
    });

    return {
        subtotal,
        discount,
        gst,
        total
    };
}

/* =========================
   Generate Bill
   ========================= */

getElement("generateBillBtn").addEventListener("click", function() {

    const customerName =
        getElement("customerName").value.trim();

    const customerMobile =
        getElement("customerMobile").value.trim();

    if (!customerName) {
        showBillingMessage("Please enter customer name.");
        return;
    }

    if (items.length === 0) {
        showBillingMessage("Please add at least one product.");
        return;
    }

    const totals = getBillTotals();

    const bill = {
        invoice: getElement("invoiceNumber").value,
        date: getElement("invoiceDate").value,
        customer: customerName,
        mobile: customerMobile,
        items: JSON.parse(JSON.stringify(items)),
        notes: getElement("billNotes").value.trim(),
        total: totals.total
    };

    bills.push(bill);

    lastGeneratedBill = bill;

    invoiceCounter++;

    showCompletePage(bill);
});

/* =========================
   Complete Page
   ========================= */

function showCompletePage(bill) {

    getElement("completeInvoice").textContent = bill.invoice;
    getElement("completeCustomer").textContent = bill.customer;
    getElement("completeTotal").textContent =
        formatCurrency(bill.total);

    preparePrintInvoice(bill);

    showPage("complete");
}

function preparePrintInvoice(bill) {

    getElement("printInvoiceNumber").textContent =
        bill.invoice;

    getElement("printDate").textContent =
        bill.date;

    getElement("printCustomer").textContent =
        bill.customer;

    getElement("printMobile").textContent =
        bill.mobile || "-";

    const printItems = getElement("printItems");

    printItems.innerHTML = "";

    bill.items.forEach(function(item) {

        const calculation = calculateItem(item);

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${escapeHTML(item.product)}</td>
            <td>${item.quantity}</td>
            <td>${formatCurrency(item.rate)}</td>
            <td>${formatCurrency(calculation.finalAmount)}</td>
        `;

        printItems.appendChild(row);
    });

    getElement("printTotal").textContent =
        formatCurrency(bill.total);
}

getElement("printBillBtn").addEventListener("click", function() {
    window.print();
});

getElement("completeNewBillBtn").addEventListener("click", function() {
    resetBillForm();
    showPage("billing");
});

getElement("completeDashboardBtn").addEventListener("click", function() {
    showPage("dashboard");
});

/* =========================
   Cancel / Reset
   ========================= */

getElement("cancelBillBtn").addEventListener("click", function() {
    resetBillForm();
    showPage("dashboard");
});

function resetBillForm() {

    items = [];

    getElement("customerName").value = "";
    getElement("customerMobile").value = "";
    getElement("billNotes").value = "";

    clearProductInputs();

    getElement("invoiceNumber").value =
        "INV-" + invoiceCounter;

    getElement("invoiceDate").value = getToday();

    hideBillingMessage();

    renderItems();
}

/* =========================
   Bills History
   ========================= */

function renderBills() {

    const tbody = getElement("billsTableBody");

    tbody.innerHTML = "";

    if (bills.length === 0) {

        const row = document.createElement("tr");

        row.innerHTML = `
            <td colspan="5" style="text-align:center;">
                No bills generated yet.
            </td>
        `;

        tbody.appendChild(row);

        return;
    }

    bills.forEach(function(bill) {

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${escapeHTML(bill.invoice)}</td>
            <td>${escapeHTML(bill.date)}</td>
            <td>${escapeHTML(bill.customer)}</td>
            <td>${escapeHTML(bill.mobile || "-")}</td>
            <td>${formatCurrency(bill.total)}</td>
        `;

        tbody.appendChild(row);
    });
}

/* =========================
   Messages
   ========================= */

function showBillingMessage(message) {

    const box = getElement("billingMessage");

    box.textContent = message;
    box.classList.add("show");
}

function hideBillingMessage() {

    const box = getElement("billingMessage");

    box.textContent = "";
    box.classList.remove("show");
}

/* =========================
   Basic HTML Safety
   ========================= */

function escapeHTML(value) {

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

/* =========================
   Initial Setup
   ========================= */

getElement("invoiceDate").value = getToday();
getElement("invoiceNumber").value = "INV-" + invoiceCounter;

renderItems();
updateDashboard();